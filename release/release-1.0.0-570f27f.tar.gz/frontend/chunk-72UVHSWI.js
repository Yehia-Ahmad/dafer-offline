function e(n){let t=typeof n=="string"?n.trim():"";return t?t.startsWith("data:image/")?t:`data:image/png;base64,${t}`:""}export{e as a};
