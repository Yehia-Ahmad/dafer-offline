function u(n,r){return n>0?r>0?n/r*100:1/0:0}function t(n,r,e){return e!==null&&u(n,r)>e+.01}export{t as a};
