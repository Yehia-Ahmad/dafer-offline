var n=r=>{if(r==null||r==="")return!0;let t=Number(r);return Number.isFinite(t)?Number.isInteger(Number((t*100).toFixed(6))):!0},o=r=>n(r.value)?null:{decimals:!0};export{n as a,o as b};
