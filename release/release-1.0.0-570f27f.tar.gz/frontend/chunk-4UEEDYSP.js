var t=(e={})=>(Object.entries(e).forEach(([r,n])=>{(n==null||n==="")&&delete e[r]}),e);export{t as a};
