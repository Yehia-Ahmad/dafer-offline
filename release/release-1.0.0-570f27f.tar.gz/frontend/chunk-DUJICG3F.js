var n={nameAr:"\u0646\u0648\u062A\u0629",nameEn:"Nota"};function r(e){return e==="ar"?n.nameAr:n.nameEn}export{n as a,r as b};
