const mongoose = require("mongoose");
const auditFieldsPlugin = require("../auth/auditFields.plugin");

const breakdownSchema = new mongoose.Schema({
  key: { type: String, required: true },
  amount: { type: Number, required: true },
}, { _id: false });

const shiftSchema = new mongoose.Schema({
  number: { type: String, required: true, unique: true, index: true },
  boxId: { type: mongoose.Schema.Types.ObjectId, ref: "CashBox", required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  userName: { type: String, trim: true },
  openedAt: { type: Date, required: true },
  // What the user counted in the drawer when opening (equal to the box balance, or confirmed and posted as shift_open).
  openingFloat: { type: Number, required: true, min: 0 },
  // The box's ledger balance when the shift opened (shown next to the float).
  openingBalance: { type: Number, default: 0 },
  // Stage 19 review: a float that differs from the box balance is confirmed with a note and posted (shift_open) to CASH_OVER_SHORT.
  openingDifference: { type: Number, default: 0 },
  openingNote: { type: String, trim: true, maxlength: 500 },
  // Ledger cut points for the "shifts" health check: entries created up to these instants make the box balance the
  // float (after the opening difference) and the counted amount (after the over/short, before the deposit).
  openCutAt: { type: Date },
  closeCutAt: { type: Date },
  // Touched by every money document written into the box, so a sale and a close conflict and one retries.
  lastActivityAt: { type: Date },
  closedAt: { type: Date },
  closedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  closedByName: { type: String, trim: true },
  expected: { type: Number },
  counted: { type: Number, min: 0 },
  difference: { type: Number },
  differenceNote: { type: String, trim: true, maxlength: 500 },
  depositBoxId: { type: mongoose.Schema.Types.ObjectId, ref: "CashBox" },
  depositAmount: { type: Number, min: 0, default: 0 },
  depositTransferId: { type: mongoose.Schema.Types.ObjectId, ref: "Transfer" },
  // The expected-cash lines as they were at close (a closed shift's report never changes).
  breakdown: { type: [breakdownSchema], default: undefined },
  // Stage 23: the sales summary of the close report (cash / credit / returns / discounts), stored at close like the breakdown.
  salesSummary: { type: mongoose.Schema.Types.Mixed, default: undefined },
  status: { type: String, enum: ["open", "closed"], default: "open", index: true },
}, { timestamps: true });

// One open shift per box, even under concurrent requests.
shiftSchema.index({ boxId: 1 }, { unique: true, partialFilterExpression: { status: "open" } });
shiftSchema.plugin(auditFieldsPlugin);
module.exports = mongoose.model("Shift", shiftSchema);
