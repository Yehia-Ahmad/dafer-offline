const mongoose = require("mongoose");
const { vatReturnLogFields } = require("./vatFields");
const auditFieldsPlugin = require("../auth/auditFields.plugin");
const { endsSetupModePlugin } = require("../accounting/setupState");

const itemSchema = new mongoose.Schema({
  invoiceItemId: { type: mongoose.Schema.Types.ObjectId },
  productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  productName: { type: String, required: true, trim: true, maxlength: 200 },
  productCode: { type: String, trim: true, maxlength: 100 },
  quantity: { type: Number, required: true, min: 1 },
  price: { type: Number, required: true, min: 0 },
  total: { type: Number, required: true, min: 0 },
  purchasePrice: { type: Number, min: 0 },
  profitAmount: { type: Number },
  returnReason: { type: String, trim: true, maxlength: 500 },
}, { _id: false });

const returnLogSchema = new mongoose.Schema({
  number: { type: String, trim: true, unique: true, sparse: true, index: true },
  returnType: { type: String, enum: ["cash", "credit"], required: true, index: true },
  invoiceId: { type: mongoose.Schema.Types.ObjectId, required: true, index: true },
  invoiceNumber: { type: String, trim: true, maxlength: 150 },
  invoiceCode: { type: String, trim: true, maxlength: 150 },
  customerName: { type: String, required: true, trim: true, maxlength: 200, index: true },
  customerPhone: { type: String, trim: true, maxlength: 30, index: true },
  returnDate: { type: Date, required: true, index: true },
  note: { type: String, trim: true, maxlength: 1000 },
  items: {
    type: [itemSchema],
    required: true,
    validate: { validator: (items) => items.length > 0, message: "يجب أن يحتوي المرتجع على عناصر" },
  },
  subtotalReturnedAmount: { type: Number, required: true, min: 0 },
  discountAmount: { type: Number, default: 0, min: 0 },
  shippingFees: { type: Number, default: 0, min: 0 },
  finalReturnedAmount: { type: Number, required: true, min: 0 },
  // Stage 19: the box a cash refund came out of (the main box on old returns; unused for credit returns).
  boxId: { type: mongoose.Schema.Types.ObjectId, ref: "CashBox", index: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  // Stage 21: the VAT this return gives back (absent for a VAT-free invoice).
  ...vatReturnLogFields(),
}, { timestamps: true });

returnLogSchema.index({ returnDate: -1, createdAt: -1 });
returnLogSchema.index({ "items.productId": 1 });
returnLogSchema.index({ "items.productCode": 1 });

// Stage 13: createdBy / updatedBy from the signed-in user (nothing when auth is off).
returnLogSchema.plugin(auditFieldsPlugin);
returnLogSchema.plugin(endsSetupModePlugin);
module.exports = mongoose.model("ReturnLog", returnLogSchema);
